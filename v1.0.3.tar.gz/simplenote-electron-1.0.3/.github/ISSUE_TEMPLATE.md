<!-- Thanks for contributing to Simplenote! Pick a clear title ("Note editor: emojis not displaying correctly") and proceed. -->

#### Steps to reproduce
1.
2.
3.
4.

#### What I expected


#### What happened instead


#### OS version


#### Screenshot / Video

<!--
PLEASE NOTE
- These comments won't show up when you submit the issue.
- Everything is optional, but try to add as many details as possible.
- If requesting a new feature, explain why you'd like to see it added.

FAQs:
https://github.com/Automattic/simplenote-electron/labels/FAQ
-->
