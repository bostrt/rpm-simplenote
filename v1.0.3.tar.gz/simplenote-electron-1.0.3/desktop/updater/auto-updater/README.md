Auto Updater
=========

Handles Squirrel auto-update events. Note that the app must be signed for this to work.

## Functions

`ping()` - checks for an update
